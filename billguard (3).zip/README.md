# BillGuard – Agentic AI Bill & Subscription Management System

> **Autonomous Multi-Agent Financial Auditor & Waste Remediation Engine**  
> *Built for the Agentic AI Hackathon*

---

## 1. Problem Statement & Executive Summary
Recurring bills, digital subscriptions, and cloud infrastructure costs have become fragmented and invisible. Consumers and small businesses routinely suffer from:
1. **Silent Rate Increases**: Merchants raising subscription prices (e.g. +30% price hikes) without prominent notice.
2. **Zombie Subscriptions**: Paid memberships remaining active for months or years with zero active logins or gym visits (>90 days idle).
3. **Duplicate Coverage**: Paying concurrently for overlapping services (e.g., Apple Music + Spotify, Dropbox + Google One).
4. **Billing Anomalies**: Accidental double charges billed within minutes.
5. **Runaway Infrastructure Waste**: Forgotten snapshots and unattached orphan cloud storage volumes.

**BillGuard** is a genuine **Agentic AI system** that does not simply summarize text or generate static advice. It operates an autonomous, state-driven workflow:
$$\text{Observe} \longrightarrow \text{Plan} \longrightarrow \text{Decide} \longrightarrow \text{Use Tools} \longrightarrow \text{Execute} \longrightarrow \text{Evaluate} \longrightarrow \text{Adapt / Replan} \longrightarrow \text{Outcome}$$

Crucially, **consequential actions** (disputing transactions, cancelling subscriptions, altering cloud tiers) are gated by an explicit **Human-in-the-Loop Safeguard**, protecting the user while preparing ready-to-execute draft notices and recovery steps.

---

## 2. System Architecture

```
                               +--------------------------------------------+
                               |           User Interaction Layer           |
                               |  - Audit Dashboard & Visual Pipeline       |
                               |  - AI Goal Mode (State Machine Runner)     |
                               |  - Human Approval & Dispute Sandbox        |
                               |  - Hackathon Demo Suite (Scenarios 1-5)    |
                               +---------------------+----------------------+
                                                     | (REST API)
                                                     v
+----------------------------------------------------+--------------------------------------------------+
|                                    BillGuard Multi-Agent Engine                                       |
|                                                                                                       |
|  +------------------------+  +--------------------------+  +---------------------------------------+  |
|  |   Bill Analyzer Agent  |  |  Anomaly Detection Agent |  |           Subscription Agent          |  |
|  | Extracts PDF/receipts  |  | Flags duplicates & hikes |  | Audits dormancy & overlapping plans   |  |
|  +-----------+------------+  +------------+-------------+  +-------------------+-------------------+  |
|              |                            |                                    |                      |
|              +----------------------------+------------------------------------+                      |
|                                           |                                                           |
|                                           v                                                           |
|  +------------------------+  +--------------------------+  +---------------------------------------+  |
|  |  Investigation Agent   |  |       Action Agent       |  |     Evaluation & Replanning Agent     |  |
|  | Verifies refund terms  |  | Prioritizes remediation  |  | Measures savings gap against target;  |  |
|  | & handles 503 fallback |  | Generates formal letters |  | Autonomously expands plan to hit goal |  |
|  +------------------------+  +--------------------------+  +---------------------------------------+  |
+----------------------------------------------------+--------------------------------------------------+
                                                     |
                                                     v
+----------------------------------------------------+--------------------------------------------------+
|                                          Agent Tool System                                            |
|                                                                                                       |
|  - bill_parser_tool: Document OCR & structured line-item normalization                                |
|  - transaction_analysis_tool: Sliding window duplicate detector (<10 mins, identical amount)          |
|  - subscription_detection_tool: Dormancy auditor (>60-90 days) & duplicate clustering                 |
|  - historical_comparison_tool: Computes variance against baselines (flags hikes >10%)                |
|  - merchant_verification_tool: Retrieves refund procedures with simulated 503 fallback                |
|  - savings_calculator_tool: Mathematical projection of monthly and annual relief                      |
+----------------------------------------------------+--------------------------------------------------+
                                                     |
                                                     v
+----------------------------------------------------+--------------------------------------------------+
|                               Persistence Layer (SQLite Database)                                     |
|  - users                     - bills                    - bill_items               - transactions     |
|  - subscriptions             - agent_goals              - agent_runs               - agent_events     |
|  - agent_actions             - approvals                - anomalies                - insights         |
+-------------------------------------------------------------------------------------------------------+
```

---

## 3. The 6 Specialized Agents

| Agent Name | Primary Responsibility | Key Outputs |
| :--- | :--- | :--- |
| **Bill Analyzer Agent** | Ingests raw invoices, statements, or uploaded files. Normalizes taxes and line items. | Structured merchant, total amount, taxes, items list. |
| **Anomaly Detection Agent** | Analyzes transaction logs for abnormal surges, double billing, and baseline variance. | Anomaly alerts with confidence scores and evidence traces. |
| **Subscription Agent** | Evaluates recurring cadence, checks member login dates, and detects duplicate providers. | Flagged dormant subscriptions (>90 days) and redundant clusters. |
| **Investigation Agent** | Queries merchant cancellation policies and dispute terms. Handles gateway failures with fallback protocols. | Cancellation procedures, dispute policies, fallback recovery notes. |
| **Action Agent** | Synthesizes findings into prioritized remediation plans with drafts and approval gates. | Action items, priorities (1-5), formal dispute letters. |
| **Evaluation & Replanning Agent** | Evaluates plan against the user's savings goal (e.g. ₹5,000). Triggers dynamic replan if a gap exists. | Goal status, target gap, replanning iteration, expanded actions. |

---

## 4. Multi-Agent Autonomous State Machine

1. **Phase 1: OBSERVE** — Ingests bills and transaction history from the SQLite database.
2. **Phase 2: PLAN** — Deconstructs the user goal into specialized sub-tasks.
3. **Phase 3: DECIDE** — Selects specific tools to query based on observed data.
4. **Phase 4: USE_TOOLS** — Executes tools (`bill_parser`, `transaction_analysis`, `merchant_verification`).
5. **Phase 5: EXECUTE** — Formulates candidate remediation actions.
6. **Phase 6: EVALUATE** — Quantifies identified savings vs target goal. If `savings < target`, automatically flags `replanning_needed: true`.
7. **Phase 7: ADAPT / REPLAN** — Autonomous Replan Loop: Expands search scope to cloud infrastructure waste (EBS snapshots) and tier downgrades to close the target gap!
8. **Phase 8: OUTCOME** — Final outcome generated; pauses in `waiting_for_approval` state for human sign-off.

---

## 5. Hackathon Evaluation Scenarios (1-Click Deterministic Demos)

All 5 scenarios are built into the UI under the **"Demo Mode"** tab and accessible via `POST /api/demo/run-scenario`:

### Scenario 1: Detect Unnecessary Subscriptions
* **What happens**: The agent audits subscriptions and flags **Cult.Fit ELITE Gym** (₹1,850/mo, >90 days idle) and duplicate music services (**Apple Music** + **Spotify**).
* **Agent behavior**: Proposes cancellation for Cult.Fit and Apple Music, saving ₹2,029/mo without degrading active routines.

### Scenario 2: Detect Suspicious Price Increase
* **What happens**: The agent checks historical baselines and detects **Netflix Premium** hiked from ₹499 to ₹649 (+30%), and **AWS Cloud Services** surged by +306% (₹850 to ₹3,450).
* **Agent behavior**: Flags anomalous line items (orphan EBS volumes) and recommends plan tier adjustment.

### Scenario 3: Tool Failure -> Fallback Strategy
* **What happens**: Merchant verification tool is forced to throw a `503 SERVICE_UNAVAILABLE` gateway error.
* **Agent behavior**: The **Investigation Agent** catches the error, records it in `state.errors`, and safely pivots to default statutory consumer protection protocols (e.g., RBI auto-debit cancellation guidelines).

### Scenario 4: User Changes Constraint -> Agent Replans
* **What happens**: User specifies constraint `"Keep Apple Music"`.
* **Agent behavior**: The agent dynamically adapts, removes Apple Music cancellation from candidate actions, and seeks alternative relief.

### Scenario 5: Savings Target Not Met -> Autonomous Replan
* **What happens**: User specifies an aggressive target of **₹5,000 monthly savings**.
* **Initial Plan**: Identifies ₹4,884 (gap of ₹116).
* **Replanning Trigger**: Evaluation Agent marks `goal_achieved: false` and routes to `ADAPT_REPLAN`.
* **Replanned Outcome**: Discovers ₹2,073.73 in orphan AWS EBS volumes & test snapshots, plus a Netflix tier downgrade (₹150), boosting total savings to **₹7,107.73/mo** (exceeding goal by ₹2,107.73)!

---

## 6. API Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Health check, DB status, and Gemini model availability |
| `POST` | `/api/bills/upload` | Upload PDF/receipt or text; extracts structured bill via OCR agent |
| `GET` | `/api/bills` | List all processed bills with line items |
| `GET` | `/api/transactions` | Query transactional ledger with duplicate badges |
| `GET` | `/api/subscriptions` | Query active subscriptions with renewal radar and dormancy flags |
| `POST` | `/api/agent/goals/:id/run` | Execute autonomous multi-agent state machine loop |
| `GET` | `/api/agent/:run_id/events` | Query event timeline (Goal -> Plan -> Decision -> Tool -> Replan -> Outcome) |
| `POST` | `/api/actions/:id/approve` | Human-in-the-Loop authorization of consequential action |
| `POST` | `/api/actions/:id/reject` | Human-in-the-Loop rejection with constraint feedback |
| `GET` | `/api/analytics/summary` | Query aggregate financial metrics and identified savings |
| `POST` | `/api/demo/run-scenario` | 1-Click execution of Scenarios 1 to 5 |
| `POST` | `/api/demo/reset-synthetic` | Reset SQLite synthetic dataset to clean baseline |

---

## 7. Setup & Run Instructions

### Prerequisites
* Node.js v20+ (v22 recommended)
* (Optional) Python 3.11+ for running the secondary FastAPI server in `/backend`

### Quick Start (Full-Stack Mode)
```bash
# 1. Install dependencies
npm install

# 2. Run automated test suite (24/24 tests)
npm run test

# 3. Start development server (serves API and React frontend on port 3000)
npm run dev

# 4. Production build
npm run build
npm start
```

### Environment Variables (`.env`)
```env
# Gemini API Key (managed via Google AI Studio)
GEMINI_API_KEY="your-gemini-api-key"

# Host Port (3000 hardcoded for container routing)
PORT=3000
```

---

## 8. Safety & Human-in-the-Loop Design
* **Zero Autonomous Execution of High-Impact Actions**: The AI can never cancel a subscription, dispute a charge, or modify cloud infrastructure without explicit human approval.
* **Audit Trail**: Every decision is justified with a confidence score, grounded evidence, and decision trace (`Why was this flagged?`).
* **Deterministic Fallback**: If the Gemini API experiences high traffic or 503 errors, the hybrid deterministic engine ensures the app remains 100% operational without failing.
